﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace struktury
{
    class Program
    {
        #region dane
        public static int rozmiarTablicy, menu, IndeksOsoby;
        public const string NAGLOWEK_PLIKU = "[BazaDanych]";
        public const string ROZMIAR_TABLICY = "RozmiarTablicy";
        public const string NAGLOWEK_OSOBY = "[Osoba]";
        public const string KLUCZ_IMIE = "Imie";
        public const string KLUCZ_NAZWISKO = "Nazwisko";
        public const string KLUCZ_WIEK = "Wiek";
        public const string KLUCZ_PESEL = "Pesel";
        #endregion

        public struct Osoba
        {
            public int wiek;
            public string imie, nazwisko, pesel;
        }

        #region rozmiar listy
        public static void rozmiarListy()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("Ile osób chcesz maksymalnie dodać do listy?");
            }
            while (!int.TryParse(Console.ReadLine(), out rozmiarTablicy)| rozmiarTablicy < 0 | rozmiarTablicy == 0);
        }
        #endregion

        #region menu
        public static void menuProgramu()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("****** MENU GŁÓWNE ******\n" +
                                      "1. Wyświetl listę osób\n" +
                                      "2. Dodaj osobę\n" +
                                      "3. Modyfikuj osobę\n" +
                                      "4. Wyświetl dane szczegółowe\n" +
                                      "5. Wczytaj dane z pliku\n" +
                                      "6. Zapisz dane do pliku\n" +
                                      "7. Informacje dodatkowe\n" +
                                      "8. Opuść aplikację\n");
            }
            while(!int.TryParse(Console.ReadLine(), out menu) | menu > 8 | menu <= 0);
        }
        #endregion

        #region wyjątki

        #region walidacja wiek
        public static void wiek(Osoba[]listaosob)
        {
            do
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine("Podaj wiek:");
            }
            while (!int.TryParse(Console.ReadLine(), out listaosob[IndeksOsoby].wiek) | listaosob[IndeksOsoby].wiek > 130 | listaosob[IndeksOsoby].wiek < 0 | listaosob[IndeksOsoby].wiek == 0);

            Console.WriteLine("\nDane wprowadzono.");
            Console.ReadKey();
        }
        #endregion

        #region walidacja imie
        public static void imie(Osoba[]listaosob)
        {
            do
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine("Podaj imie:");
                listaosob[IndeksOsoby].imie = Console.ReadLine();
            }
            while (string.IsNullOrEmpty(listaosob[IndeksOsoby].imie));

            Console.WriteLine("\nDane wprowadzono.");
            Console.ReadKey();
        }
        #endregion

        #region walidacja nazwisko
        public static void nazwisko(Osoba[] listaosob)
        {
            do
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine("Podaj nazwisko:");
                listaosob[IndeksOsoby].nazwisko = Console.ReadLine();
            }
            while (string.IsNullOrEmpty(listaosob[IndeksOsoby].nazwisko));

            Console.WriteLine("\nDane wprowadzono.");
            Console.ReadKey();
        }
        #endregion

        #region walidacja pesel
        public static void pesel(Osoba[]listaosob)
        {
            do
            {
                string pesel;
                int[] waga = {1,3,7,9,1,3,7,9,1,3};
                double[] suma = new double[10];
                double[] peselConverted = new double[11];
                double sumaCalosci = 0, modulo = 10, rezultat, rezultatKoncowy, wynik;

                do
                {
                    Console.Clear();
                    Console.WriteLine("Wprowadź dane:\n");
                    Console.WriteLine("Podaj pesel:");
                    pesel = Console.ReadLine();
                }
                while (pesel.Length != 11);

                for (int i = 0; i < 11; i++)
                {
                    peselConverted[i] = char.GetNumericValue(pesel[i]);
                }

                double sumaKontrolna = peselConverted[10];

                for (int i = 0; i < 10; i++)
                {
                    suma[i] = (waga[i] * peselConverted[i]);
                    sumaCalosci += suma[i];
                }

                rezultat = sumaCalosci % modulo;
                rezultatKoncowy = modulo - rezultat;
                wynik = rezultatKoncowy % modulo;

                if (sumaKontrolna == wynik)
                {
                    listaosob[IndeksOsoby].pesel = pesel;
                    Console.WriteLine("\nDane wprowadzono.");
                    break;
                }

                else
                {
                    Console.WriteLine("\nBłędny pesel!");
                    Console.ReadKey();
                }
            }
            while (true);
        }
        #endregion

        #endregion

        #region wyświetlanie listy
        public static void wypisywanieListyOsob(Osoba[] listaosob, int rozmiartablicy)
        {
            Console.Clear();

            if(listaosob[0].wiek == 0)
            {
                Console.WriteLine("Brak danych");
                return;
            }

            for (int i = 0; i < rozmiartablicy; i++)
            {
                if (listaosob[i].wiek != 0)
                {
                    Console.WriteLine($"{i+1} {listaosob[i].imie} {listaosob[i].nazwisko}");
                }
            }  
        }
        #endregion

        #region dodawanie osoby
        public static void dodawanieOsoby(Osoba[] listaosob, int rozmiartablicy)
        {
            Console.Clear();  

            if(listaosob[listaosob.Length-1].wiek != 0)
            {
                Console.WriteLine($"Błąd, baza danych jest już pełna!\n\nPodałeś rozmiar listy osób: {rozmiartablicy}\nOraz dodałeś ilość osób: {rozmiartablicy}");
                return;
            }

            imie(listaosob);
            nazwisko(listaosob);
            wiek(listaosob);
            pesel(listaosob);
         
            IndeksOsoby++;
        }
        #endregion

        #region modyfikowanie osoby
         public static void modyfikujOsobe(Osoba[]listaosob)
         {
            Console.Clear();

            if(listaosob[0].wiek == 0)
            {
                Console.WriteLine("Brak danych");
                return;
            }

            int ilosc = 0;

            for (int i = 0; i < rozmiarTablicy; i++)
            {
                if (listaosob[i].wiek != 0)
                {
                    ilosc++;
                }
            }

            do
            {
                Console.Clear();
                Console.WriteLine("Lista wszystkich osób w bazie:\n");

                    for (int i = 0; i < rozmiarTablicy; i++)
                    {
                        if (listaosob[i].wiek != 0)
                        {
                            Console.WriteLine($"{i + 1} {listaosob[i].imie} {listaosob[i].nazwisko}");
                        }
                    }
                    Console.Write("\nPodaj numer osoby, którą chcesz edytować:   "); 
            }
            while (!int.TryParse(Console.ReadLine(), out IndeksOsoby) | IndeksOsoby < 0| IndeksOsoby > ilosc | IndeksOsoby == 0);

            string wprowadzanieImie = "";
            string wprowadzanieNazwisko = "";

            while (string.IsNullOrEmpty(wprowadzanieImie))
            {
                    Console.Clear();
                    Console.WriteLine("Wprowadź dane:\n");
                    Console.WriteLine($"Obecne imię to: {listaosob[IndeksOsoby - 1].imie}\nCzy chcesz zmienić imię? (Y - tak | Dowolny klawisz - nie\n");

                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    while (string.IsNullOrEmpty(wprowadzanieImie))
                    {
                        Console.Clear();
                        Console.WriteLine("Wprowadź dane:\n");
                        Console.WriteLine("Podaj imie:");
                        wprowadzanieImie = Console.ReadLine();
                        listaosob[IndeksOsoby - 1].imie = wprowadzanieImie; 
                    }
                    Console.WriteLine("\nDane wprowadzono.");
                }
                else
                {
                    Console.WriteLine("\nImię pozsotaje bez zmian.");
                    break;
                }
            }

            Console.ReadKey();

            while (string.IsNullOrEmpty(wprowadzanieNazwisko))
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine($"Obecne nazwisko to: {listaosob[IndeksOsoby - 1].nazwisko}\nCzy chcesz zmienić nazwisko? (Y - tak | Dowolny klawisz - nie\n");

                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    while (string.IsNullOrEmpty(wprowadzanieNazwisko))
                    {
                        Console.Clear();
                        Console.WriteLine("Wprowadź dane:\n");
                        Console.WriteLine("Podaj nazwisko:");
                        wprowadzanieNazwisko = Console.ReadLine();
                        listaosob[IndeksOsoby - 1].nazwisko = wprowadzanieNazwisko;
                    }
                    Console.WriteLine("\nDane wprowadzono.");
                }
                else
                {
                    Console.WriteLine("\nNazwisko pozsotaje bez zmian.");
                    break;
                }
            }

            Console.ReadKey();

            do
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine($"Obecny wiek to: {listaosob[IndeksOsoby - 1].wiek}\nCzy chcesz zmienić wiek? (Y - tak | Dowolny klawisz - nie\n");

                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    do
                    {
                        Console.Clear();
                        Console.WriteLine("Wprowadź dane:\n");
                        Console.WriteLine("Podaj wiek:");
                    }
                    while (!int.TryParse(Console.ReadLine(), out listaosob[IndeksOsoby - 1].wiek) | listaosob[IndeksOsoby - 1].wiek > 130 | listaosob[IndeksOsoby - 1].wiek < 0 | listaosob[IndeksOsoby - 1].wiek == 0);
                    Console.WriteLine("\nDane wprowadzono.");
                    break;
                }

                else
                {
                    Console.WriteLine("Wiek pozostaje bez zmian");
                    break;
                }
            }
            while (true);
            Console.ReadKey();

            do
            {
                Console.Clear();
                Console.WriteLine("Wprowadź dane:\n");
                Console.WriteLine($"Obecny pesel to: {listaosob[IndeksOsoby - 1].pesel}\nCzy chcesz zmienić pesel? (Y - tak | Dowolny klawisz - nie\n");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    do
                    {
                        string pesel;
                        int[] waga = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
                        double[] suma = new double[10];
                        double[] peselConverted = new double[11];
                        double sumaCalosci = 0, modulo = 10, rezultat, rezultatKoncowy, wynik;

                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Wprowadź dane:\n");
                            Console.WriteLine("Podaj pesel:");
                            pesel = Console.ReadLine();
                        }
                        while (pesel.Length != 11);

                        for (int i = 0; i < 11; i++)
                        {
                            peselConverted[i] = char.GetNumericValue(pesel[i]);
                        }

                        double sumaKontrolna = peselConverted[10];

                        for (int i = 0; i < 10; i++)
                        {
                            suma[i] = (waga[i] * peselConverted[i]);
                            sumaCalosci += suma[i];
                        }

                        rezultat = sumaCalosci % modulo;
                        rezultatKoncowy = modulo - rezultat;
                        wynik = rezultatKoncowy % modulo;

                        if (sumaKontrolna == wynik)
                        {
                            listaosob[IndeksOsoby - 1].pesel = pesel;
                            Console.WriteLine("\nDane wprowadzono.");
                            break;
                        }

                        else
                        {
                            Console.WriteLine("\nBłędny pesel!");
                            Console.ReadKey();
                        } 
                    }
                    while (true);
                    break;
                }
                else
                {
                    Console.WriteLine("Pesel pozostaje bez zmian");
                    break;
                }
            }
            while (true);
        }
        #endregion

        #region wyświetlanie szczegółowej listy
        public static void wyswietlSzczegoly(Osoba[]listaosob, int rozmiartablicy)
        {
            Console.Clear();

           if(listaosob[0].wiek == 0)
           {
                Console.WriteLine("Brak danych");
                return;
           }

            int osoba;
            int ilosc = 0;

            for (int i = 0; i < rozmiartablicy; i++)
            {
                if(listaosob[i].wiek != 0)
                {
                    ilosc++;
                }
            }

            do
            {
                Console.Clear();
                Console.WriteLine("Lista wszystkich osób w bazie:\n");

                for (int i = 0; i < rozmiartablicy; i++)
                {
                    if (listaosob[i].wiek != 0)
                    {
                        Console.WriteLine($"{i + 1} {listaosob[i].imie} {listaosob[i].nazwisko}");
                    }
                }

                Console.WriteLine();
                Console.Write("Którą osobę z listy chcesz wyświetlić? (wpisz numer):   ");   
            }
            while (!int.TryParse(Console.ReadLine(), out osoba) | osoba < 0 | osoba > ilosc| osoba == 0);

            Console.WriteLine($"\n{osoba} {listaosob[osoba-1].imie} {listaosob[osoba-1].nazwisko} {listaosob[osoba-1].wiek} {listaosob[osoba-1].pesel}");        
        }
        #endregion

        #region odczyt danych z pliku

        public static bool Odczyt(string nazwaPliku, out Osoba[] listaosob)
        {
            listaosob = null;

            if (string.IsNullOrEmpty(nazwaPliku))
                return false;

            try
            {
                using (StreamReader plik = new StreamReader(nazwaPliku))
                {
                    string Linia = plik.ReadLine();

                    if (Linia != NAGLOWEK_PLIKU)
                        throw new Exception("Błędny nagłówek pliku!");

                    Linia = plik.ReadLine();
                    string[] KluczWartosc = Linia.Split('=');

                    if (KluczWartosc[0] != ROZMIAR_TABLICY)
                        throw new Exception("Błędna informacja o dlugosci tablicy!");

                    int Dlugosc = int.Parse(KluczWartosc[1]);

                    if (Dlugosc < 1)
                        throw new Exception("Zły rozmiar tablicy! Musi byc >=1");

                    listaosob = new Osoba[Dlugosc];

                    int IndeksOsoby = -1;

                    while (true)
                    {
                        if (plik.EndOfStream)
                            break;

                        Linia = plik.ReadLine();

                        if (Linia == NAGLOWEK_OSOBY)
                            IndeksOsoby++;

                        if (IndeksOsoby > Dlugosc - 1)
                            break;

                        if (Linia != NAGLOWEK_OSOBY)
                        {
                            KluczWartosc = Linia.Split('=');
                            if (KluczWartosc.Length == 2)
                            {
                                if (KluczWartosc[0] == KLUCZ_IMIE)
                                    listaosob[IndeksOsoby].imie = KluczWartosc[1];
                                else if (KluczWartosc[0] == KLUCZ_NAZWISKO)
                                    listaosob[IndeksOsoby].nazwisko = KluczWartosc[1];
                                else if (KluczWartosc[0] == KLUCZ_WIEK)
                                {
                                    int.TryParse(KluczWartosc[1], out listaosob[IndeksOsoby].wiek);
                                }
                                else if (KluczWartosc[0] == KLUCZ_PESEL)
                                    listaosob[IndeksOsoby].pesel = KluczWartosc[1];
                            }
                        }
                    }

                }

                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine($"Błąd: {e.Message}");
                listaosob = null;
            }

            return false;
        }
        #endregion

        #region zapis danych do pliku

        public static bool zapis(string nazwaPliku, Osoba[]listaosob)
        {
            string tworzeniePliku = "plikzdanymi.txt";
            nazwaPliku = tworzeniePliku;
            if (string.IsNullOrEmpty(nazwaPliku) || listaosob == null || listaosob.Length < 1)
            {
                return false;
            }

            try
            {
                using (StreamWriter plik = new StreamWriter(nazwaPliku))
                {
                    plik.WriteLine(NAGLOWEK_PLIKU);
                    plik.WriteLine($"{ROZMIAR_TABLICY}={listaosob.Length}");

                    foreach (var osoba in listaosob)
                    {
                        plik.WriteLine(NAGLOWEK_OSOBY);
                        plik.WriteLine($"{KLUCZ_IMIE}={osoba.imie}");
                        plik.WriteLine($"{KLUCZ_NAZWISKO}={osoba.nazwisko}");
                        plik.WriteLine($"{KLUCZ_WIEK}={osoba.wiek}");
                        plik.WriteLine($"{KLUCZ_PESEL}={ osoba.pesel}");
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine($"Błąd: {e.Message}");
            }

            return false;
        }
        #endregion

        static void Main(string[] args)
        {
            rozmiarListy();

            Osoba[] listaosob = new Osoba[rozmiarTablicy];

            Console.Clear();

            #region menu
            while (true)
            {
                Console.Clear();

                menuProgramu();

                switch (menu)
                {
                    case 1:
                        wypisywanieListyOsob(listaosob, rozmiarTablicy);
                        Console.ReadKey();
                        break;
                    case 2:
                        dodawanieOsoby(listaosob, rozmiarTablicy);
                        Console.ReadKey();
                        break;
                    case 3:
                        modyfikujOsobe(listaosob);
                        Console.ReadKey();
                        break;
                    case 4:
                        wyswietlSzczegoly(listaosob, rozmiarTablicy);
                        Console.ReadKey();
                        break;
                    case 5:
                        #region odczyt z pliku
                        string NazwaPliku = "";
                        Odczyt(NazwaPliku, out listaosob);
                        if (Odczyt(@"plikzdanymi.txt", out listaosob))
                        {
                            Console.WriteLine("\nDane zostały wczytane oraz dodane do listy.");
                        }
                        else
                        {
                            Console.WriteLine("\nNie udało się wczytać danych z pliku.");
                        }
                        Console.ReadKey();
                        #endregion
                        break;
                    case 6:
                        #region zapis do pliku
                        string nazwaPliku = "";
                        zapis(nazwaPliku, listaosob);
                        if (zapis(@"c:/plikzdanymi.txt", listaosob))
                        {
                            Console.WriteLine("\nDane zostały zapisane do pliku.");
                        }
                        else
                        {
                            Console.WriteLine("\nNie udało się zapisać danych do pliku.");
                        }
                        Console.ReadKey();
                        #endregion
                        break;
                    case 7:
                        #region informacje
                        Console.Clear();
                        int ilosc = 0;

                        for (int i = 0; i < rozmiarTablicy; i++)
                        {
                            if (listaosob[i].wiek != 0)
                            {
                                ilosc++;
                            }
                        }
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("Autorem aplikacji jest: Damian Czerwiński\n");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"Lista pomieści ilość osób: {rozmiarTablicy}");
                        Console.WriteLine($"Obecnie ilość dodanych osób: {ilosc}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.ReadKey();
                        #endregion
                        break;
                    case 8:
                        return;
                }
            }
            #endregion
        }
    }
}




